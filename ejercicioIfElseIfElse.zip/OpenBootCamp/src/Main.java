public class Main {
    public static void main(String[] args) {
        var numeroIf = 5;

        if (numeroIf > 0) {
                System.out.println("Es positivo");
        } else if (numeroIf < 0) {
                System.out.println("Es negativo");
        } else {
                System.out.println("Es 0");
        }
    }
}